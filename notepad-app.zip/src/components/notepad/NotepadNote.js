import React from 'react'

export const NotepadNote = () => {
    return (
        <div className="notepad__note pointer">
            <div 
                className="notepad__note-thumbnail"
                style={{
                    backgroundSize: 'cover',
                    backgroundImage: 'url(https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Notepad_icon.svg/1024px-Notepad_icon.svg.png)'
                }}
            ></div>
            <div className="notepad__note-body">
                <p className="notepad__note-title">
                    fsociety.dat
                </p>
                <p className="notepad__note-content">
                    Leave me here.
                </p>
            </div>
            <div className="notepad__note-date-box">
                <span>Monday</span>
                <h4>28</h4>
            </div>
        </div>
    )
}
