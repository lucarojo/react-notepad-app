import React from 'react'
import { NotepadNote } from './NotepadNote'

export const NotepadNotes = () => {
    
    const notes = [1,2,3,4,5]
    
    return (
        <div className="notepad__notes">
            {
                notes.map( note => (
                    <NotepadNote key={ note } />
                ))
            }
        </div>
    )
}
