import React from 'react'
import { NotepadNotes } from './NotepadNotes'

export const Sidebar = () => {
    return (
        <aside className="notepad__sidebar">
            <div className="notepadd_sidebar-navbar">
                <h3 className="mt-5">
                    <i className="far fa-user"></i>
                    <span> User</span>
                </h3>

                <button className="btn">
                    Logout
                </button>
            </div>

            <div className="notepad__new-note">
                <i className="far fa-sticky-note fa-5x"></i>
                <p className="mt-5">New note</p>
            </div>

            <NotepadNotes />
        </aside>
    )
}
