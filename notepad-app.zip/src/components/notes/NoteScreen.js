import React from 'react'
import { NotesAppBar } from './NotesAppBar'

export const NoteScreen = () => {
    return (
        <div className="notes__main-content">
            <NotesAppBar />

            <div className="notes__content">
                <input 
                    type="text"
                    placeholder="notes title"
                    className="notes__title-input"
                    autoComplete="off"
                />
                <textarea 
                    placeholder="what happen"
                    className="notes__textarea"
                ></textarea>

                <div className="notes__image">
                    <img 
                        src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Notepad_icon.svg/1024px-Notepad_icon.svg.png"
                        alt="Image"    
                    />
                </div>
            </div>
        </div>
    )
}
