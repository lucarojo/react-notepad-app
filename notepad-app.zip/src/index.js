import React from 'react';
import ReactDOM from 'react-dom';
import { NotepadApp } from './NotepadApp';
import './styles/styles.scss'

ReactDOM.render(
  <NotepadApp />,
  document.getElementById('root')
);